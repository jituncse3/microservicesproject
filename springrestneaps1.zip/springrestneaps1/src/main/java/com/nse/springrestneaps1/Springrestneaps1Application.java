package com.nse.springrestneaps1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springrestneaps1Application {

	public static void main(String[] args) {
		SpringApplication.run(Springrestneaps1Application.class, args);
	}

}
