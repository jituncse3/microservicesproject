package com.nse.restjwteureka1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Restjwteureka1Application {

	public static void main(String[] args) {
		SpringApplication.run(Restjwteureka1Application.class, args);
	}

}
