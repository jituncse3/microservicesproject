package com.nseindia.redis.repo;

import org.springframework.data.repository.CrudRepository;

import com.nseindia.redis.model.IpoActiveCategory;

public interface IpoActiveCategoryRepository  extends CrudRepository<IpoActiveCategory, String>{

}
