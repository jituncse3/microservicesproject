package com.nseindia.redis.model;

import org.springframework.data.redis.core.RedisHash;

@RedisHash("cd_offline")
public class CDOffline extends CD{

	public long marketLot;
	public double annualisedVolatility;
	public long clientWisePositionLimits;
	public long marketWidePositionLimits;
	public double turnoverinBase;
	public double premiumTurnOver;
	public double premiumTurnOverBase;
	public double openInterest;
	public double dailyVolatility;
	public long tradeCount;
	public double underlyingValue;
	public double settlementPrice;
	public double prevOI;
	public double totalTurnover;
	public int noOfContractsTraded;
	
	//calculated
	public double changeinOpenInterest;
	public double pchangeinOpenInterest;
	public double impliedVolatility;
	
	public void setParentData(CD cd)
	{
		if(cd!=null)
		{
			marketType = cd.marketType;
			buyPrice1 = cd.buyPrice1;
			buyQuantity1 = cd.buyQuantity1;
			buyPrice2 = cd.buyPrice2;
			buyQuantity2 = cd.buyQuantity2;
			buyPrice3 = cd.buyPrice3;
			buyQuantity3 = cd.buyQuantity3;
			buyPrice4 = cd.buyPrice4;
			buyQuantity4 = cd.buyQuantity4;
			buyPrice5 = cd.buyPrice5;
			buyQuantity5 = cd.buyQuantity5;
			sellPrice1 = cd.sellPrice1;
			sellQuantity1 = cd.sellQuantity1;
			sellPrice2 = cd.sellPrice2;
			sellQuantity2 = cd.sellQuantity2;
			sellPrice3 = cd.sellPrice3;
			sellQuantity3 = cd.sellQuantity3;
			sellPrice4 = cd.sellPrice4;
			sellQuantity4 = cd.sellQuantity4;
			sellPrice5 = cd.sellPrice5;
			sellQuantity5 = cd.sellQuantity5;
			lastPrice = cd.lastPrice;
			totalTradedVolume = cd.totalTradedVolume;
			secStatus = cd.secStatus;
			openPrice = cd.openPrice;
			highPrice = cd.highPrice;
			lowPrice = cd.lowPrice;
			prevClose = cd.prevClose;
			avgtradePrice = cd.avgtradePrice;
			totalBuyQuantity = cd.totalBuyQuantity;
			totalSellQuantity = cd.totalSellQuantity;
			last_updatedTime = cd.last_updatedTime;   
			change=cd.change;
			pChange=cd.pChange;
		}
	}
	
}