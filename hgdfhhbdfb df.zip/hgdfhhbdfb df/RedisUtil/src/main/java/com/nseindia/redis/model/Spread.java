package com.nseindia.redis.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;
import org.springframework.data.redis.core.index.Indexed;

@RedisHash("spread_online")
public class Spread {
	@Id
	public String identifier;
	@Indexed public String instrument;
	public String symbol;
	public double strikePrice;
	public String optionType;
	public String instrument2;
	public String symbol2;
	public double strikePrice2;
	public String optionType2;
	public String expiryDate;
	public double buyPrice1;
	public long buyQuantity1;
	public double buyPrice2;
	public long buyQuantity2;
	public double buyPrice3;
	public long buyQuantity3;
	public double buyPrice4;
	public long buyQuantity4;
	public double buyPrice5;
	public long buyQuantity5;
	public double sellPrice1;
	public long sellQuantity1;
	public double sellPrice2;
	public long sellQuantity2;
	public double sellPrice3;
	public long sellQuantity3;
	public double sellPrice4;
	public long sellQuantity4;
	public double sellPrice5;
	public long sellQuantity5;
	public double openPriceDiff;
	public double highpriceDiff;
	public double lowPriceDiff;
	public double ltpDIff;
	public double totBuyVol;
	public double totSellVol;
	public double totTradeVol;
	public String timeStamp;
	public Spread(String identifier, String instrument, String symbol, double strikePrice, String optionType,
			String instrument2, String symbol2, double strikePrice2, String optionType2, String expiryDate,
			double buyPrice1, long buyQuantity1, double buyPrice2, long buyQuantity2, double buyPrice3,
			long buyQuantity3, double buyPrice4, long buyQuantity4, double buyPrice5, long buyQuantity5,
			double sellPrice1, long sellQuantity1, double sellPrice2, long sellQuantity2, double sellPrice3,
			long sellQuantity3, double sellPrice4, long sellQuantity4, double sellPrice5, long sellQuantity5,
			double openPriceDiff, double highpriceDiff, double lowPriceDiff, double ltpDIff, double totBuyVol,
			double totSellVol, double totTradeVol, String timeStamp) {
		super();
		this.identifier = identifier;
		this.instrument = instrument;
		this.symbol = symbol;
		this.strikePrice = strikePrice;
		this.optionType = optionType;
		this.instrument2 = instrument2;
		this.symbol2 = symbol2;
		this.strikePrice2 = strikePrice2;
		this.optionType2 = optionType2;
		this.expiryDate = expiryDate;
		this.buyPrice1 = buyPrice1;
		this.buyQuantity1 = buyQuantity1;
		this.buyPrice2 = buyPrice2;
		this.buyQuantity2 = buyQuantity2;
		this.buyPrice3 = buyPrice3;
		this.buyQuantity3 = buyQuantity3;
		this.buyPrice4 = buyPrice4;
		this.buyQuantity4 = buyQuantity4;
		this.buyPrice5 = buyPrice5;
		this.buyQuantity5 = buyQuantity5;
		this.sellPrice1 = sellPrice1;
		this.sellQuantity1 = sellQuantity1;
		this.sellPrice2 = sellPrice2;
		this.sellQuantity2 = sellQuantity2;
		this.sellPrice3 = sellPrice3;
		this.sellQuantity3 = sellQuantity3;
		this.sellPrice4 = sellPrice4;
		this.sellQuantity4 = sellQuantity4;
		this.sellPrice5 = sellPrice5;
		this.sellQuantity5 = sellQuantity5;
		this.openPriceDiff = openPriceDiff;
		this.highpriceDiff = highpriceDiff;
		this.lowPriceDiff = lowPriceDiff;
		this.ltpDIff = ltpDIff;
		this.totBuyVol = totBuyVol;
		this.totSellVol = totSellVol;
		this.totTradeVol = totTradeVol;
		this.timeStamp = timeStamp;
	}
	public Spread() {
		super();
	}	

}
