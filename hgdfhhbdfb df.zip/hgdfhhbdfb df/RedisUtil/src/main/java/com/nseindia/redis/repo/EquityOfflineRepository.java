package com.nseindia.redis.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.nseindia.redis.model.EquityOffline;

public interface EquityOfflineRepository extends CrudRepository<EquityOffline, String>{
	
	EquityOffline findBySymbol(String symbol);
	List<EquityOffline> findAllBySymbol(String symbol);

}
