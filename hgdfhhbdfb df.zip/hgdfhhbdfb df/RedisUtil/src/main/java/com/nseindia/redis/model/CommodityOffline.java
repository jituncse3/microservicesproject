package com.nseindia.redis.model;

import org.springframework.data.redis.core.RedisHash;

@RedisHash("commodity_offline")
public class CommodityOffline extends Commodity{
	
	public double openInterest;
	public double prevOI;
	public long tradeCount;
	public String spm_lot_size;
	public double spotPrice;
	public double spotPrice1;
	public double spotPrice2;
	public String attachment;
	//calculated
	public double changeinOpenInterest;
	public double pchangeinOpenInterest;

	public void setParentData(Commodity commodity)
	{
		if(commodity!=null)
		{
			marketType = commodity.marketType;
			buyPrice1 = commodity.buyPrice1;
			buyQuantity1 = commodity.buyQuantity1;
			buyPrice2 = commodity.buyPrice2;
			buyQuantity2 = commodity.buyQuantity2;
			buyPrice3 = commodity.buyPrice3;
			buyQuantity3 = commodity.buyQuantity3;
			buyPrice4 = commodity.buyPrice4;
			buyQuantity4 = commodity.buyQuantity4;
			buyPrice5 = commodity.buyPrice5;
			buyQuantity5 = commodity.buyQuantity5;
			sellPrice1 = commodity.sellPrice1;
			sellQuantity1 = commodity.sellQuantity1;
			sellPrice2 = commodity.sellPrice2;
			sellQuantity2 = commodity.sellQuantity2;
			sellPrice3 = commodity.sellPrice3;
			sellQuantity3 = commodity.sellQuantity3;
			sellPrice4 = commodity.sellPrice4;
			sellQuantity4 = commodity.sellQuantity4;
			sellPrice5 = commodity.sellPrice5;
			sellQuantity5 = commodity.sellQuantity5;
			lastPrice = commodity.lastPrice;
			totalTradedVolume = commodity.totalTradedVolume;
			secStatus = commodity.secStatus;
			openPrice = commodity.openPrice;
			highPrice = commodity.highPrice;
			lowPrice = commodity.lowPrice;
			prevClose = commodity.prevClose;
			avgtradePrice = commodity.avgtradePrice;
			totalBuyQuantity = commodity.totalBuyQuantity;
			totalSellQuantity = commodity.totalSellQuantity;
			last_updatedTime = commodity.last_updatedTime;   
			change=commodity.change;
			pChange=commodity.pChange;
			totalTurnover=commodity.totalTurnover;
			instrumentType=commodity.instrumentType;
			underlying=commodity.underlying;
			expiryDate=commodity.expiryDate;
			strikePrice=commodity.strikePrice;
			optionType=commodity.optionType;							
		}
	}
	
	
}
