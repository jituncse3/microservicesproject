package com.nseindia.redis.model;

import java.io.Serializable;
import java.time.LocalDate;

import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;

@RedisHash("irfYieldMaster")
public class IRFYieldMaster implements Serializable{

	@Id
	public String identifier;
	public String instrumentType;
	public String underlying;
	public LocalDate expiryDate;
	public LocalDate maturityDate;
	public double couponRate;
	public LocalDate settOnExpiry;
	public LocalDate settDate;
	public String timestamp;
	
}
