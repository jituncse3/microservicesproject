package com.nseindia.redis.repo;

import org.springframework.data.repository.CrudRepository;

import com.nseindia.redis.model.CashFlowData;

public interface CashFlowRepository extends CrudRepository<CashFlowData, String>{

}
