package com.nseindia.redis.model;

import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;
/**
 * <h1>Index</h1>
 * 
 * @author abhishekp
 * @version 1.0
 * @since 06-Sep-2018
 */
@RedisHash("index")
public class Index implements Serializable{

	@Id
	public String indexName;
	public double open;
	public double high;
	public double low;
	public double last;
	public double previousClose;
	public double percChange;
	public double yearHigh;
	public double yearLow;
	public String timeVal;
	
	public Index() {
	}
	
	public Index(String indexName, double open, double high, double low, double last, double previousClose,
			double percChange, double yearHigh, double yearLow, String timeVal) {
		super();
		this.indexName = indexName;
		this.open = open;
		this.high = high;
		this.low = low;
		this.last = last;
		this.previousClose = previousClose;
		this.percChange = percChange;
		this.yearHigh = yearHigh;
		this.yearLow = yearLow;
		this.timeVal = timeVal;
	}
	
}
