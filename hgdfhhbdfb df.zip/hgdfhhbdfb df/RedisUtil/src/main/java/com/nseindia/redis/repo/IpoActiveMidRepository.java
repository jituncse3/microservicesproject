package com.nseindia.redis.repo;

import org.springframework.data.repository.CrudRepository;

import com.nseindia.redis.model.IpoActiveMid;

public interface IpoActiveMidRepository extends CrudRepository<IpoActiveMid, String>{

}
