package com.nseindia.redis.model;

import org.springframework.data.redis.core.RedisHash;

@RedisHash("equity_offline")
public class EquityOffline extends Equity{
	
	public String companyName;
	public String isinCode;
	public String secStatus;
	public double faceValue;
	public double ffmc;
	public String yearHightDt;
	public String yearLowDt;
	public String priceBand;
	public String pPriceBand;
	public String exDate;
	public String purpose;
	public String secWiseDelPosDate;
	public int quantityTraded;
	public int deliveryQuantity;
	public double deliveryToTradedQuantity;
	public double securityVar;
	public double indexVar;
	public double extremeLossMargin;
	public double varMargin;
	public double adhocMargin;
	public double applicableMargin;
	public double basePrice;
	public double closePrice;
	public String industry;
	public String listingDate;
	public double impactCost;
	public long issuedCap;
	

	//calculated
	public double yearHigh;
	public double yearLow;
	public double change;
	public double pChange;
	
	//Debt
	public DebtOffline secInfo;
	
	public EquityOffline() {
	}

	public void setParentData(Equity equity)
	{
		if(equity!=null)
		{
			identifier=		equity.identifier;
			symbol=			equity.symbol;
			series=			equity.series;
			marketType=		equity.marketType;
			buyPrice1=		equity.buyPrice1;
			buyQuantity1=		equity.buyQuantity1;
			buyPrice2=		equity.buyPrice2;
			buyQuantity2=		equity.buyQuantity2;
			buyPrice3=		equity.buyPrice3;
			buyQuantity3=		equity.buyQuantity3;
			buyPrice4=		equity.buyPrice4;
			buyQuantity4=		equity.buyQuantity4;
			buyPrice5=		equity.buyPrice5;
			buyQuantity5=		equity.buyQuantity5;
			sellPrice1=		equity.sellPrice1;
			sellQuantity1=		equity.sellQuantity1;
			sellPrice2=		equity.sellPrice2;
			sellQuantity2=		equity.sellQuantity2;
			sellPrice3=		equity.sellPrice3;
			sellQuantity3=		equity.sellQuantity3;
			sellPrice4=		equity.sellPrice4;
			sellQuantity4=		equity.sellQuantity4;
			sellPrice5=		equity.sellPrice5;
			sellQuantity5=		equity.sellQuantity5;
			lastPrice=		equity.lastPrice;
			totalTradedVolume=	equity.totalTradedVolume;
			status=			equity.status;
			open=			equity.open;
			dayHigh=		equity.dayHigh;
			dayLow=			equity.dayLow;
			previousClose=		equity.previousClose;
			averagePrice=		equity.averagePrice;
			totalBuyQuantity=	equity.totalBuyQuantity;
			totalSellQuantity=	equity.totalSellQuantity;
			onlineIndex=		equity.onlineIndex;
			lastUpdateTime=		equity.lastUpdateTime;
			totalTradedValue= equity.totalTradedValue;
			
			change=lastPrice- (basePrice!=0.0 ? basePrice : previousClose);
			pChange=(change/(basePrice!=0.0 ? basePrice : previousClose))*100;
			
			/*Commented as for securities with no trade dayLow and dayHigh are 0*/
			/*if(yearHigh<dayHigh)
				yearHigh=dayHigh;
			if(yearLow>dayLow)
				yearLow=dayLow;*/
		}
	}	
	
}
