package com.nseindia.redis.repo;

import org.springframework.data.repository.CrudRepository;

import com.nseindia.redis.model.IpoData;

public interface IpodataRepository  extends CrudRepository<IpoData,String >{

}
