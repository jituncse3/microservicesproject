package com.nseindia.redis.model;

public class IpoActiveDebtBidPojo {
	private String srNo;
	private String category;
	private String noOfSharesOffered;
	private String noOfsharesBid;
	private String noOfTime;
	/**
	 * @return the srNo
	 */
	public String getSrNo() {
		return srNo;
	}
	/**
	 * @param srNo the srNo to set
	 */
	public void setSrNo(String srNo) {
		this.srNo = srNo;
	}
	/**
	 * @return the category
	 */
	public String getCategory() {
		return category;
	}
	/**
	 * @param category the category to set
	 */
	public void setCategory(String category) {
		this.category = category;
	}
	/**
	 * @return the noOfSharesOffered
	 */
	public String getNoOfSharesOffered() {
		return noOfSharesOffered;
	}
	/**
	 * @param noOfSharesOffered the noOfSharesOffered to set
	 */
	public void setNoOfSharesOffered(String noOfSharesOffered) {
		this.noOfSharesOffered = noOfSharesOffered;
	}
	/**
	 * @return the noOfsharesBid
	 */
	public String getNoOfsharesBid() {
		return noOfsharesBid;
	}
	/**
	 * @param noOfsharesBid the noOfsharesBid to set
	 */
	public void setNoOfsharesBid(String noOfsharesBid) {
		this.noOfsharesBid = noOfsharesBid;
	}
	/**
	 * @return the noOfTime
	 */
	public String getNoOfTime() {
		return noOfTime;
	}
	/**
	 * @param noOfTime the noOfTime to set
	 */
	public void setNoOfTime(String noOfTime) {
		this.noOfTime = noOfTime;
	}
	
}
