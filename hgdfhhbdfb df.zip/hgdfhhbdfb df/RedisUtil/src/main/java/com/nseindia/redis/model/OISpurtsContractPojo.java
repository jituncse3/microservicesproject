package com.nseindia.redis.model;

public class OISpurtsContractPojo{
	
	private String type;
	private String symbol;
	private String instrument;
	private String expiryDate;
	private String optionType;
	private double strikePrice;
	private double ltp;
	private double prevClose;
	private double pChange;
	private long latestOI;
	private long prevOI;
	private int changeInOI;
	private long volume;
	private long turnover;
	private long premTurnover;
	private double underlyingValue;
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	public String getInstrument() {
		return instrument;
	}
	public void setInstrument(String instrument) {
		this.instrument = instrument;
	}
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	public String getOptionType() {
		return optionType;
	}
	public void setOptionType(String optionType) {
		this.optionType = optionType;
	}
	public double getStrikePrice() {
		return strikePrice;
	}
	public void setStrikePrice(double strikePrice) {
		this.strikePrice = strikePrice;
	}
	public double getLtp() {
		return ltp;
	}
	public void setLtp(double ltp) {
		this.ltp = ltp;
	}
	public double getPrevClose() {
		return prevClose;
	}
	public void setPrevClose(double prevClose) {
		this.prevClose = prevClose;
	}
	public double getpChange() {
		return pChange;
	}
	public void setpChange(double pChange) {
		this.pChange = pChange;
	}
	public long getLatestOI() {
		return latestOI;
	}
	public void setLatestOI(long latestOI) {
		this.latestOI = latestOI;
	}
	public long getPrevOI() {
		return prevOI;
	}
	public void setPrevOI(long prevOI) {
		this.prevOI = prevOI;
	}
	public int getChangeInOI() {
		return changeInOI;
	}
	public void setChangeInOI(int changeInOI) {
		this.changeInOI = changeInOI;
	}
	public long getVolume() {
		return volume;
	}
	public void setVolume(long volume) {
		this.volume = volume;
	}
	public long getTurnover() {
		return turnover;
	}
	public void setTurnover(long turnover) {
		this.turnover = turnover;
	}
	public long getPremTurnover() {
		return premTurnover;
	}
	public void setPremTurnover(long premTurnover) {
		this.premTurnover = premTurnover;
	}
	public double getUnderlyingValue() {
		return underlyingValue;
	}
	public void setUnderlyingValue(double underlyingValue) {
		this.underlyingValue = underlyingValue;
	}

}
