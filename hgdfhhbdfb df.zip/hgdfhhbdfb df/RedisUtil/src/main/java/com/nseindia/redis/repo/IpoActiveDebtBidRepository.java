package com.nseindia.redis.repo;

import org.springframework.data.repository.CrudRepository;

import com.nseindia.redis.model.IpoActiveDebtBid;

public interface IpoActiveDebtBidRepository extends CrudRepository<IpoActiveDebtBid, String>{

}
