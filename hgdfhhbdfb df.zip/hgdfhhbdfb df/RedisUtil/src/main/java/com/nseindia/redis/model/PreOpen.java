package com.nseindia.redis.model;

import org.springframework.data.redis.core.RedisHash;

@RedisHash("preOpen")
public class PreOpen extends PreOpenOffline{
	
	public String symbol;
	public String series;
	public String marketType;
	public double buyPrice1;
	public long buyQuantity1;
	public double buyPrice2;
	public long buyQuantity2;
	public double buyPrice3;
	public long buyQuantity3;
	public double buyPrice4;
	public long buyQuantity4;
	public double buyPrice5;
	public long buyQuantity5;
	public double sellPrice1;
	public long sellQuantity1;
	public double sellPrice2;
	public long sellQuantity2;
	public double sellPrice3;
	public long sellQuantity3;
	public double sellPrice4;
	public long sellQuantity4;
	public double sellPrice5;
	public long sellQuantity5;
	public double lastPrice;
	public long totalTradedVolume;
	public String status;
	public double IEP;
	public double dayHigh;
	public double dayLow;
	public double previousClose;
	public double averagePrice;
	public long totalBuyQuantity;
	public long totalSellQuantity;
	public double onlineIndex;
	public String lastUpdateTime;
	
	//Calculated
	public double totalTurnover;
	public double change;
	public double pChange;
	
	public PreOpen() {
	}

	public PreOpen(String identifier, String symbol, String series, String marketType, double buyPrice1,
			long buyQuantity1, double buyPrice2, long buyQuantity2, double buyPrice3, long buyQuantity3,
			double buyPrice4, long buyQuantity4, double buyPrice5, long buyQuantity5, double sellPrice1,
			long sellQuantity1, double sellPrice2, long sellQuantity2, double sellPrice3, long sellQuantity3,
			double sellPrice4, long sellQuantity4, double sellPrice5, long sellQuantity5, double lastPrice,
			long totalTradedVolume, String status, double iEP, double dayHigh, double dayLow, double previousClose,
			double averagePrice, long totalBuyQuantity, long totalSellQuantity, double onlineIndex,
			String lastUpdateTime, PreOpenOffline offline) {
		super();
		this.identifier = identifier;
		this.symbol = symbol;
		this.series = series;
		this.marketType = marketType;
		this.buyPrice1 = buyPrice1;
		this.buyQuantity1 = buyQuantity1;
		this.buyPrice2 = buyPrice2;
		this.buyQuantity2 = buyQuantity2;
		this.buyPrice3 = buyPrice3;
		this.buyQuantity3 = buyQuantity3;
		this.buyPrice4 = buyPrice4;
		this.buyQuantity4 = buyQuantity4;
		this.buyPrice5 = buyPrice5;
		this.buyQuantity5 = buyQuantity5;
		this.sellPrice1 = sellPrice1;
		this.sellQuantity1 = sellQuantity1;
		this.sellPrice2 = sellPrice2;
		this.sellQuantity2 = sellQuantity2;
		this.sellPrice3 = sellPrice3;
		this.sellQuantity3 = sellQuantity3;
		this.sellPrice4 = sellPrice4;
		this.sellQuantity4 = sellQuantity4;
		this.sellPrice5 = sellPrice5;
		this.sellQuantity5 = sellQuantity5;
		this.lastPrice = lastPrice;
		this.totalTradedVolume = totalTradedVolume;
		this.status = status;
		IEP = iEP;
		this.dayHigh = dayHigh;
		this.dayLow = dayLow;
		this.previousClose = previousClose;
		this.averagePrice = averagePrice;
		this.totalBuyQuantity = totalBuyQuantity;
		this.totalSellQuantity = totalSellQuantity;
		this.onlineIndex = onlineIndex;
		this.lastUpdateTime = lastUpdateTime;
		if(offline!=null)
		{
			yearHigh=offline.yearHigh;
			yearLow=offline.yearLow;
			marketCap=offline.marketCap;
			basePrice=offline.basePrice;
			finalQuantity=offline.finalQuantity;
			exDate=offline.exDate;
			purpose=offline.purpose;
		}
		totalTurnover = totalTradedVolume*averagePrice;
		change=lastPrice- (basePrice!=0.0 ? basePrice : previousClose);
		pChange=(change/(basePrice!=0.0 ? basePrice : previousClose))*100;
	}

}
