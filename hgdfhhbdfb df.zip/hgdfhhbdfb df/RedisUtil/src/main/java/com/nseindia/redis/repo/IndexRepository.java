package com.nseindia.redis.repo;

import org.springframework.data.repository.CrudRepository;

import com.nseindia.redis.model.Index;

public interface IndexRepository extends CrudRepository<Index, String>{

}
