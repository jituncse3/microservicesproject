package com.nseindia.redis.model;

import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;
import org.springframework.data.redis.core.index.Indexed;
@RedisHash("slb_online")
public class SLB implements Serializable{
	@Id
	 public String indetifier;
	 public String symbol;
	 @Indexed public String  series;
	 public String  marketType;
	 public double buyOrderPrice1;
	 public int buyOrderQty1;
	 public double buyOrderPrice2;
	 public int buyOrderQty2;
	 public double buyOrderPrice3;
	 public int buyOrderQty3;
	 public double buyOrderPrice4;
	 public int buyOrderQty4;
	 public double buyOrderPrice5;
	 public int buyOrderQty5;
	 public double sellOrederPrice1;
	 public int sellQty1;
	 public double sellOrederPrice2;
	 public int sellQty2;
	 public double sellOrederPrice3;
	 public int sellQty3;
	 public double sellOrederPrice4;
	 public int sellQty4;
	 public double sellOrederPrice5;
	 public int sellQty5;
	 public double lastTradedPrice;
	 public int totTradedQty;
	 public String securityStatus;
	 public double openingPrice;
	 public double highPrice;
	 public double lowPrice;
	 public double closePrice;
	 public double avgTradePrice;
	 public int totBuyQty;
	 public  int totSellQty;
	 public double onlineIndex;
	 public String revLegSettDt;
	 public String timeStamp;
	public SLB(String indetifier, String symbol, String series, String marketType, double buyOrderPrice1,
			int buyOrderQty1, double buyOrderPrice2, int buyOrderQty2, double buyOrderPrice3, int buyOrderQty3,
			double buyOrderPrice4, int buyOrderQty4, double buyOrderPrice5, int buyOrderQty5, double sellOrederPrice1,
			int sellQty1, double sellOrederPrice2, int sellQty2, double sellOrederPrice3, int sellQty3,
			double sellOrederPrice4, int sellQty4, double sellOrederPrice5, int sellQty5, double lastTradedPrice,
			int totTradedQty, String securityStatus, double openingPrice, double highPrice, double lowPrice,
			double closePrice, double avgTradePrice, int totBuyQty, int totSellQty, double onlineIndex,
			String revLegSettDt, String timeStamp) {
		super();
		this.indetifier = indetifier;
		this.symbol = symbol;
		this.series = series;
		this.marketType = marketType;
		this.buyOrderPrice1 = buyOrderPrice1;
		this.buyOrderQty1 = buyOrderQty1;
		this.buyOrderPrice2 = buyOrderPrice2;
		this.buyOrderQty2 = buyOrderQty2;
		this.buyOrderPrice3 = buyOrderPrice3;
		this.buyOrderQty3 = buyOrderQty3;
		this.buyOrderPrice4 = buyOrderPrice4;
		this.buyOrderQty4 = buyOrderQty4;
		this.buyOrderPrice5 = buyOrderPrice5;
		this.buyOrderQty5 = buyOrderQty5;
		this.sellOrederPrice1 = sellOrederPrice1;
		this.sellQty1 = sellQty1;
		this.sellOrederPrice2 = sellOrederPrice2;
		this.sellQty2 = sellQty2;
		this.sellOrederPrice3 = sellOrederPrice3;
		this.sellQty3 = sellQty3;
		this.sellOrederPrice4 = sellOrederPrice4;
		this.sellQty4 = sellQty4;
		this.sellOrederPrice5 = sellOrederPrice5;
		this.sellQty5 = sellQty5;
		this.lastTradedPrice = lastTradedPrice;
		this.totTradedQty = totTradedQty;
		this.securityStatus = securityStatus;
		this.openingPrice = openingPrice;
		this.highPrice = highPrice;
		this.lowPrice = lowPrice;
		this.closePrice = closePrice;
		this.avgTradePrice = avgTradePrice;
		this.totBuyQty = totBuyQty;
		this.totSellQty = totSellQty;
		this.onlineIndex = onlineIndex;
		this.revLegSettDt = revLegSettDt;
		this.timeStamp = timeStamp;
	}
	public SLB() {
		super();
	}
	
	
}
