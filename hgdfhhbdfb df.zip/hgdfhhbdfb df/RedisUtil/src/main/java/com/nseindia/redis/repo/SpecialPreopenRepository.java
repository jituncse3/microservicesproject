package com.nseindia.redis.repo;

import org.springframework.data.repository.CrudRepository;

import com.nseindia.redis.model.SpecialPreopen;

public interface SpecialPreopenRepository extends CrudRepository<SpecialPreopen, String>{

}
