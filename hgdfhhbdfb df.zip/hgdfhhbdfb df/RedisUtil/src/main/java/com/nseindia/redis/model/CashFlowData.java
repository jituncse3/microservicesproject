package com.nseindia.redis.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;

@RedisHash("cash_flow")
public class CashFlowData implements Serializable {
	
	@Id
	private String identifier;
	private List<Double> cashFlows;
	private List<LocalDate> paymentDates;
	private LocalDate settlementDate;
	private String skip;
	
	public String getIdentifier() {
		return identifier;
	}
	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}
	public List<Double> getCashFlows() {
		return cashFlows;
	}
	public void setCashFlows(List<Double> cashFlows) {
		this.cashFlows = cashFlows;
	}
	public List<LocalDate> getPaymentDates() {
		return paymentDates;
	}
	public void setPaymentDates(List<LocalDate> paymentDates) {
		this.paymentDates = paymentDates;
	}
	public LocalDate getSettlementDate() {
		return settlementDate;
	}
	public void setSettlementDate(LocalDate settlementDate) {
		this.settlementDate = settlementDate;
	}
	public String getSkip() {
		return skip;
	}
	public void setSkip(String skip) {
		this.skip = skip;
	}
	@Override
	public String toString() {
		return "{\"identifier\":\"" + identifier + "\", \"cashFlows\":\"" + cashFlows + "\", \"paymentDates\":\""
				+ paymentDates + "\", \"settlementDate\":\"" + settlementDate + "\", \"skip\":\"" + skip + "\"}";
	}
}
