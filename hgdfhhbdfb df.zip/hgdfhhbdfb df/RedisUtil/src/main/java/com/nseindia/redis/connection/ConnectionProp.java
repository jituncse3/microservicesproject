package com.nseindia.redis.connection;

import java.util.HashSet;
import java.util.Set;

import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.JedisCluster;

public class ConnectionProp {

	public static String hostname="hostip redis";
	
	public static int port=8763;
	
	public static String node1;
	public static int port1;
	public static String node2;
	public static int port2;
	
	
	static
	{
		if(System.getenv("REDIS_NODE_1")!=null)
		{
			node1=System.getenv("REDIS_NODE_1");
			port1=Integer.parseInt(System.getenv("REDIS_PORT_1"));
			node2=System.getenv("REDIS_NODE_2");
			port2=Integer.parseInt(System.getenv("REDIS_PORT_2"));
		}
		else
		{
			node1="redishost1";
			port1=port1;
			node2="redishost2";
			port2=port2;
		}
	}
	
	public static JedisCluster getRedisConnection()
	{
		Set<HostAndPort> cluserConf=new HashSet<>();
		cluserConf.add(new HostAndPort(node1, port1));
		cluserConf.add(new HostAndPort(node2, port2));
		return new JedisCluster(cluserConf);
	}
	
}

