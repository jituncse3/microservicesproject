package com.nseindia.redis.model;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;

@RedisHash("ipo_active_mid")
public class IpoActiveMid implements Serializable {

	@Id
	private String symbol;
	private List<IpoActiveMidPojo> dataList;
	/**
	 * @return the symbol
	 */
	public String getSymbol() {
		return symbol;
	}
	/**
	 * @param symbol the symbol to set
	 */
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	/**
	 * @return the dataList
	 */
	public List<IpoActiveMidPojo> getDataList() {
		return dataList;
	}
	/**
	 * @param dataList the dataList to set
	 */
	public void setDataList(List<IpoActiveMidPojo> dataList) {
		this.dataList = dataList;
	}
	
}
