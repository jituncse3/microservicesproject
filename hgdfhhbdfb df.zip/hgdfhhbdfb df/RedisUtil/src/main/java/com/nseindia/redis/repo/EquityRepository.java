package com.nseindia.redis.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.nseindia.redis.model.Equity;

public interface EquityRepository extends CrudRepository<Equity, String>{

	Equity findBySymbol(String symbol);
	List<Equity> findAllBySymbol(String symbol);
 	
}
