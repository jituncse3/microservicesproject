package com.nseindia.redis.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import com.nseindia.redis.model.CA2;

public interface CA2Repository extends CrudRepository<CA2, String> {

	List<CA2> findAllBysessionId(int sessionId);
}
