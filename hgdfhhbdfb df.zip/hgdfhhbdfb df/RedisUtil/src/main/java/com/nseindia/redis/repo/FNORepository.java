package com.nseindia.redis.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.nseindia.redis.model.FNO;

public interface FNORepository extends CrudRepository<FNO, String>{
	
	List<FNO> findAllByInstrumentType(String instrumentType);

}
