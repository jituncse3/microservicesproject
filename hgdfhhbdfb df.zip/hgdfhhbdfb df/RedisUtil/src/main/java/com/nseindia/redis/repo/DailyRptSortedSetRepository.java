package com.nseindia.redis.repo;

import com.nseindia.redis.model.ReportPojo;


import java.util.List;
import java.util.Set;

import javax.annotation.Resource;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.stereotype.Repository;

@Repository
public class DailyRptSortedSetRepository {

	@Resource(name="redisTemplate")
	ZSetOperations<String, String> sortedSetOps;

	public DailyRptSortedSetRepository() {
	}

	public void addFileObject(String key, String value, Double score) {
		sortedSetOps.add(key, value, score.doubleValue());
	}

	public Set<String> getAllFileObjects(String key) {
		return sortedSetOps.range(key, 0L, -1L);
	}

	public Set<String> getFileObjectsByRange(String key, long start, long stop) {
		return sortedSetOps.range(key, start, stop);
	}

	public void emptyFilekeySet(String key) {
		sortedSetOps.removeRange(key, 0L, -1L);
	}

	public void addAllFilekeys(String key, List<ReportPojo> list) {
		
		for(ReportPojo reportObj : list){
			sortedSetOps.add(key, reportObj.getFileHashKey(),reportObj.getFilePosition().doubleValue());
		}
		
		
	}

}
