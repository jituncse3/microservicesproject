package com.nseindia.redis.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;
import org.springframework.data.redis.core.index.Indexed;

@RedisHash("ca2_status")
public class CA2Status {
	@Id
	private String identifier;
	private String packetIden;
	@Indexed private String sessionId;
	private String timestamp;
	private String seqNo;
	private String mktType;
	
	public CA2Status(String identifier, String packetIden, String sessionId, String timestamp, String seqNo,
			String mktType) {
		super();
		this.identifier = identifier;
		this.packetIden = packetIden;
		this.sessionId = sessionId;
		this.timestamp = timestamp;
		this.seqNo = seqNo;
		this.mktType = mktType;
	}

	public CA2Status() {
		super();
	}

	public String getPacketIden() {
		return packetIden;
	}

	public void setPacketIden(String packetIden) {
		this.packetIden = packetIden;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}
	
	
	
	
}
