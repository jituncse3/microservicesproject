package com.nseindia.redis.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.nseindia.redis.model.PriTradeRepoPojo;

@Repository
public interface TradeRepoDataRepository extends CrudRepository<PriTradeRepoPojo,String>  {}
