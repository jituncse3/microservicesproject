package com.nseindia.redis.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.nseindia.redis.model.SLB;

public interface SLBRepository extends CrudRepository<SLB, String>{

	List<SLB> findAllBySeries(String series);
}
