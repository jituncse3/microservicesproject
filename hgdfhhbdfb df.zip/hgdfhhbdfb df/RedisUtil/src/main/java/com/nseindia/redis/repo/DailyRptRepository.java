package com.nseindia.redis.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.nseindia.redis.model.ReportPojo;

@Repository
public interface DailyRptRepository extends CrudRepository<ReportPojo,String> {}
