package com.nseindia.redis.util;

public class KeyMapper {
	
	public static String cmSuggest="equitySuggest";
	public static String cdMaster="cdGetQuoteMasterData";
	public static String cdSuggest="cdSuggest";
	public static String fnoMaster="fnoGetQuoteMasterData";
	public static String foSuggest="foSuggest";
	public static String ilqContractMaster="ilqContractMasterData";
	public static String currTradeDate="currTradingDate";
	public static String prevTradeDate="prevTradingDate";
	public static String comSuggest="comSuggest";
	public static String comMaster="comGetQuoteMasterData";
	public static String smeSeries="smSeries";
	public static String caSecurities="caSecurities";
	public static String slbSecurities="slbSecurities";
	public static String maxTimestamp="maxTimestamp";
	public static String preopenStatus="preopenStatus";
	public static String maxTimestampForGraph="maxTimestampForGraph";
	public static String graphIdentifiers="graphIdentifiers";
	public static String irfSuggest="irfSuggest";
	public static String indexPrevClose="indexPrevClose";
	public static String etfSymbolList="etfSymbolList";
	public static String basePriceBl="basePriceBl";
	public static String seriesMasterSeriesA="seriesMasterSeriesA";
	public static String seriesMasterSeriesB="seriesMasterSeriesB";
	public static String irfMaster="irfGetQuoteMasterData";
	public static String mfSuggest="mfSuggestData";
	public static String derivativeToCashRatio="derivativeToCashRatio";
}
