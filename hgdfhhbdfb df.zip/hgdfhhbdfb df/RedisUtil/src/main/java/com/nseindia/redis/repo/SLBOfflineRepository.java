package com.nseindia.redis.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.nseindia.redis.model.SLBOffline;

public interface SLBOfflineRepository  extends CrudRepository<SLBOffline, String>{
	List<SLBOffline> findAllBySeries(String series);
}
