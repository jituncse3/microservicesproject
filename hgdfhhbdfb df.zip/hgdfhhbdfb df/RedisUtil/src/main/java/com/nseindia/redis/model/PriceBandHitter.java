package com.nseindia.redis.model;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;

@RedisHash("priceBand")
public class PriceBandHitter implements Serializable{
	@Id
	public String indetifier;
	public Map<String,String> count;
	public List<PriceBandHittersPojo> data;
	public String timestamp;

}
