package com.nseindia.redis.model;

import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;

@RedisHash("ipo_data")
public class IpoData implements Serializable{

	@Id	
	private String issue;
	private  String[] issueDetails;
	/**
	 * @return the issue
	 */
	public String getIssue() {
		return issue;
	}
	/**
	 * @param issue the issue to set
	 */
	public void setIssue(String issue) {
		this.issue = issue;
	}
	/**
	 * @return the issueDetails
	 */
	public String[] getIssueDetails() {
		return issueDetails;
	}
	/**
	 * @param issueDetails the issueDetails to set
	 */
	public void setIssueDetails(String[] issueDetails) {
		this.issueDetails = issueDetails;
	}
	
}
