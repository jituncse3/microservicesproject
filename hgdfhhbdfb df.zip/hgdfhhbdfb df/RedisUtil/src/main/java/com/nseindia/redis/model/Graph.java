package com.nseindia.redis.model;

import java.io.Serializable;
import java.util.ArrayList;

import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;

@RedisHash("intraDay")
public class Graph implements Serializable{

	@Id
	public String identifier;
	public String name;
	public String grapthData;
	public double closePrice;
	
}
