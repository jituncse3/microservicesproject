package com.nseindia.redis.model;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;

@RedisHash("pritraderepo")
public class PriTradeRepoPojo {

	@Id
	private String trHashId;
	private String isin;
	private String secDesc;
	private String issueSize;
	private String issuePrice;
	private String issueDate;
	private String interestFreq;
	private String firstIntrstPymntDate;
	private String maturityDate;
	private String putOptionDesc;
	private String callOptionDesc;
	private List<String> creditRatingDetails;

	public PriTradeRepoPojo() {
		super();
	}

	public PriTradeRepoPojo(String trHashId, String isin, String secDesc, String issueSize, String issuePrice,
			String issueDate, String interesFreq, String firstIntrstPymntDate, String maturityDate,
			String putOptionDesc, String callOptionDesc) {
		super();
		this.trHashId = trHashId;
		this.isin = isin;
		this.secDesc = secDesc;
		this.issueSize = issueSize;
		this.issuePrice = issuePrice;
		this.issueDate = issueDate;
		this.interestFreq = interesFreq;
		this.firstIntrstPymntDate = firstIntrstPymntDate;
		this.maturityDate = maturityDate;
		this.putOptionDesc = putOptionDesc;
		this.callOptionDesc = callOptionDesc;
	}

	public String getTrHashId() {
		return trHashId;
	}

	public void setTrHashId(String trHashId) {
		this.trHashId = trHashId;
	}

	public String getIsin() {
		return isin;
	}

	public void setIsin(String isin) {
		this.isin = isin;
	}

	public String getSecDesc() {
		return secDesc;
	}

	public void setSecDesc(String secDesc) {
		this.secDesc = secDesc;
	}

	public String getIssueSize() {
		return issueSize;
	}

	public void setIssueSize(String issueSize) {
		this.issueSize = issueSize;
	}

	public String getIssuePrice() {
		return issuePrice;
	}

	public void setIssuePrice(String issuePrice) {
		this.issuePrice = issuePrice;
	}

	public String getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(String issueDate) {
		this.issueDate = issueDate;
	}

	public String getInterestFreq() {
		return interestFreq;
	}

	public void setInterestFreq(String interestFreq) {
		this.interestFreq = interestFreq;
	}

	public String getFirstIntrstPymntDate() {
		return firstIntrstPymntDate;
	}

	public void setFirstIntrstPymntDate(String firstIntrstPymntDate) {
		this.firstIntrstPymntDate = firstIntrstPymntDate;
	}

	public String getMaturityDate() {
		return maturityDate;
	}

	public void setMaturityDate(String maturityDate) {
		this.maturityDate = maturityDate;
	}

	public String getPutOptionDesc() {
		return putOptionDesc;
	}

	public void setPutOptionDesc(String putOptionDesc) {
		this.putOptionDesc = putOptionDesc;
	}

	public String getCallOptionDesc() {
		return callOptionDesc;
	}

	public void setCallOptionDesc(String callOptionDesc) {
		this.callOptionDesc = callOptionDesc;
	}

	public List<String> getCreditRatingDetails() {
		return creditRatingDetails;
	}
	
	public String getCreditRatingDetailsAsString() {
		String response = "";
		if(creditRatingDetails!=null && !creditRatingDetails.isEmpty()){
			for(String listObj : getCreditRatingDetails()){
				response += listObj+" | ";
			}
		}
		return response;
	}

	public void setCreditRatingDetails(List<String> creditRatingDetails) {
		this.creditRatingDetails = creditRatingDetails;
	}

}
